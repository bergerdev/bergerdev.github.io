To use clsHero call it with this function. If it is not working properly or have questions, contact me at query@bergerwork.com.

void cls()
{
    system(“   (wherever you have the script located)    /clear.scpt");
}