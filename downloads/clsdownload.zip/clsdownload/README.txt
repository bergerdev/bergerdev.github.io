To clear the Xcode console, call this function. If it is not working properly or have questions, contact me at contact@bergerdev.com.

void cls()
{
    system(“   (wherever you have the script located)    /clear.scpt");
}